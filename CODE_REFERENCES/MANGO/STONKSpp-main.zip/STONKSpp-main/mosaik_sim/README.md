# Under dev
Launch cosimaWorld.py and it'll do the magic 